
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <div class="container">
                        <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success col-md-6 mx-auto" style="padding: 5px; margin-bottom: 5px;">
                                <p class="text-center"><?php echo e(session('success')); ?></p>
                            </div>
                    </div>
                    <?php endif; ?>
                      <?php if(\Session::has('update')): ?>
                            <div class="alert alert-success col-md-6 mx-auto" style="padding: 5px; margin-bottom: 5px;">
                                <p class="text-center"><?php echo e(session('update')); ?></p>
                            </div>
                    </div>
                    <?php endif; ?>

                      <?php if(\Session::has('delete')): ?>
                            <div class="alert alert-success col-md-6 mx-auto" style="padding: 5px; margin-bottom: 5px;">
                                <p class="text-center"><?php echo e(session('delete')); ?></p>
                            </div>
                    </div>
                    <?php endif; ?>
                    <h5 class="card-title mb-4 d-inline">Hometypes</h5>
                    <a href="<?php echo e(route('admins.create.hometypes')); ?>"
                        class="btn btn-primary mb-4 text-center float-right">Create Hometypes</a>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">name</th>
                                <th scope="col">update</th>
                                <th scope="col">delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $hometypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hometype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($hometype->id); ?></th>
                                    <td><?php echo e($hometype->hometypes); ?></td>
                                    <td><a href="<?php echo e(route('admins.edit.hometypes',  $hometype->id )); ?>"
                                            class="btn btn-warning text-white text-center ">Update</a></td>
                                    <td><a href="<?php echo e(route('admins.delete.hometypes',  $hometype->id)); ?>" class="btn btn-danger  text-center ">Delete</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admins', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\noure\Agence-de-Location-immobili-re\projet\resources\views/admins/hometypes.blade.php ENDPATH**/ ?>