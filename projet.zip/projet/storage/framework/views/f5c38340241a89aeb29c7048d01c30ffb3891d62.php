<?php $__env->startSection('content'); ?>
    <div class="site-blocks-cover inner-page-cover overlay"
    style="background-image: url('/assets/images/example-image.jpg');" data-aos="fade">


        <div class="container">
            <div class="row align-items-center justify-content-center text-center">
                <div class="col-md-10">
                    <span class="d-inline-block text-white px-3 mb-3 property-offer-type rounded">Property Details
                        of</span>
                    <h1 class="mb-2"><?php echo e($singleProp->title); ?></h1>
                    <p class="mb-5"><strong class="h2 text-success font-weight-bold">$<?php echo e($singleProp->price); ?></strong></p>
                </div>
            </div>
        </div>
    </div>

    <?php if(\Session::has('success')): ?>
        <div class="alert alert-success col-md-6 mx-auto" style="padding: 5px; margin-bottom: 5px;">
            <p class="text-center"><?php echo e(session('success')); ?></p>
        </div>
    <?php endif; ?>

    <?php if(\Session::has('save')): ?>
        <div class="alert alert-success col-md-6 mx-auto" style="padding: 5px; margin-bottom: 5px;">
            <p class="text-center"><?php echo e(session('save')); ?></p>
        </div>
    <?php endif; ?>

    <div class="site-section site-section-sm">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div>
                        <div class="slide-one-item home-slider owl-carousel">
                            <?php $__currentLoopData = $propImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div><img src="<?php echo e(asset('assets/images_gallery/' . $propImage->image)); ?>" alt="Image"
                                        class="img-fluid">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="bg-white property-body border-bottom border-left border-right">
                        <div class="row mb-5">
                            <div class="col-md-6">
                                <strong class="text-success h1 mb-3">$<?php echo e($singleProp->price); ?></strong>
                            </div>
                            <div class="col-md-6">
                                <ul class="property-specs-wrap mb-3 mb-lg-0  float-lg-right">
                                    <li>
                                        <span class="property-specs">Beds</span>
                                        <span class="property-specs-number"><?php echo e($singleProp->beds); ?> <sup>+</sup></span>

                                    </li>
                                    <li>
                                        <span class="property-specs">Baths</span>
                                        <span class="property-specs-number"><?php echo e($singleProp->baths); ?></span>

                                    </li>
                                    <li>
                                        <span class="property-specs">SQ FT</span>
                                        <span class="property-specs-number"><?php echo e($singleProp->sq_ft); ?></span>

                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="row mb-5">
                            <div class="col-md-6 col-lg-4 text-center border-bottom border-top py-3">
                                <span class="d-inline-block text-black mb-0 caption-text">Home Type</span>
                                <strong class="d-block"><?php echo e($singleProp->homeType->hometypes); ?></strong>
                            </div>
                            <div class="col-md-6 col-lg-4 text-center border-bottom border-top py-3">
                                <span class="d-inline-block text-black mb-0 caption-text">Year Built</span>
                                <strong class="d-block"><?php echo e($singleProp->year_built); ?></strong>
                            </div>
                            <div class="col-md-6 col-lg-4 text-center border-bottom border-top py-3">
                                <span class="d-inline-block text-black mb-0 caption-text">Price/Sqft</span>
                                <strong class="d-block">$<?php echo e($singleProp->price_sqft); ?></strong>
                            </div>
                        </div>
                        <h2 class="h4 text-black">More Info</h2>
                        <p><?php echo e($singleProp->more_info); ?></p>
                        <div class="row no-gutters mt-5">
                            <div class="col-12">
                                <h2 class="h4 text-black mb-3">Gallery</h2>
                            </div>
                            <?php $__currentLoopData = $propImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-sm-6 col-md-4 col-lg-3">
                                    <a href="<?php echo e(asset('assets/images_gallery/' . $propImage->image)); ?>"
                                        class="image-popup gal-item">
                                        <img src="<?php echo e(asset('assets/images_gallery/' . $propImage->image)); ?>" alt="Image"
                                            class="img-fluid">
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4">

                    <div class="bg-white widget border rounded">

                        <h3 class="h4 text-black widget-title mb-3">Contact Agent</h3>
                        <?php if(isset(Auth::user()->id)): ?>
                            <?php if($validateFormCount > 0): ?>
                                <p class="alert alert-success"> You already sent a request to this property</p>
                            <?php else: ?>
                                <form method="POST" action="<?php echo e(route('insert.request', $singleProp->id)); ?>"
                                    class="form-contact-agent">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="name">prop_id</label>
                                        <input type="text" value="<?php echo e($singleProp->id); ?>" id="name" name="prop_id"
                                            type="hidden" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="name">Agent Name</label>
                                        <input type="text" id="name" name="agent_name" type="hidden"
                                            value="<?php echo e($singleProp->agent_name); ?>" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="text" id="name" name="name" class="form-control">
                                    </div>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="email" id="email" name="email" class="form-control">
                                    </div>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="form-group">
                                        <label for="phone">Phone</label>
                                        <input type="text" id="phone" name="phone" class="form-control">
                                    </div>
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="form-group">
                                        <input type="submit" id="phone" name="submit" class="btn btn-primary"
                                            value="Send Request">
                                    </div>
                                </form>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="form-group">
                                <a class="alert alert-success" href="<?php echo e(route('login')); ?>">Login </a>
                                <p class="alert alert-success mt-2">to send e request to
                                    this property</p>
                            </div>
                        <?php endif; ?>

                    </div>

                    <div class="bg-white widget border rounded">
                        <form method="POST" action="<?php echo e(route('save.prop', $singleProp->id)); ?>"
                            class="form-contact-agent">
                            <?php echo csrf_field(); ?>
                            <h3 class="h4 text-black widget-title mb-3">Save Properties</h3>
                            <?php if(isset(Auth::user()->id)): ?>
                                <?php if($validateSavingPropsCount > 0): ?>
                                    <p class="alert alert-warning">
                                        You already saved properties this property
                                    </p>
                                <?php else: ?>
                                    <div class="form-group">
                                        <input type="hidden" value="<?php echo e($singleProp->id); ?>" id="name"
                                            name="prop_id" type="hidden" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="hidden" id="title" name="title" type="hidden"
                                            value="<?php echo e($singleProp->title); ?>" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="hidden" value="<?php echo e($singleProp->image); ?>" id="name"
                                            name="image" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="hidden" value="<?php echo e($singleProp->location); ?>" id="email"
                                            name="location" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="hidden" value="<?php echo e($singleProp->price); ?>" id="email"
                                            name="price" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" id="phone" name="submit" class="btn btn-primary"
                                            value="Save Property">
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="form-group">
                                    <a class="alert alert-success" href="<?php echo e(route('login')); ?>">Login </a>
                                    <p class="alert alert-success mt-2">to send e request to
                                        this property</p>
                                </div>
                            <?php endif; ?>

                        </form>

                    </div>

                    <div class="bg-white widget border rounded">
                        <h3 class="h4 text-black widget-title mb-3 ml-0">Share</h3>
                        <div class="px-3" style="margin-left: -15px;">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($singleProp->id); ?>&quote=<?php echo e($singleProp->title); ?>"
                                class="pt-3 pb-3 pr-3 pl-0"><span class="icon-facebook"></span></a>
                            <a href="https://twitter.com/intent/tweet?text=<?php echo e($singleProp->title); ?>&url=<?php echo e($singleProp->id); ?>"
                                class="pt-3 pb-3 pr-3 pl-0"><span class="icon-twitter"></span></a>
                            <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo e($singleProp->id); ?>"
                                class="pt-3 pb-3 pr-3 pl-0"><span class="icon-linkedin"></span></a>
                        </div>

                    </div>

                </div>

            </div>
        </div>
    </div>

    <div class="site-section site-section-sm bg-light">
        <div class="container">

            <div class="row">
                <div class="col-12">
                    <div class="site-section-title mb-5">
                        <h2>Related Properties</h2>
                    </div>
                </div>
            </div>

            <div class="row mb-5">
                <?php if($relatedProps->count() > 0): ?>
                    <?php $__currentLoopData = $relatedProps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="property-entry h-100">
                                <a href="<?php echo e(route('single.prop', $relatedProp->id)); ?>" class="property-thumbnail">
                                    <div class="offer-type-wrap">
                                        <span class="offer-type bg-danger">Sale</span>
                                        <span class="offer-type bg-success"><?php echo e($relatedProp->type); ?></span>
                                    </div>
                                    <img src="<?php echo e(asset('assets/images/' . $relatedProp->image . '')); ?>" alt="Image"
                                        class="img-fluid">
                                </a>
                                <div class="p-4 property-body">
                                    <a href="#" class="property-favorite"><span class="icon-heart-o"></span></a>
                                    <h2 class="property-title"><a
                                            href="<?php echo e(route('single.prop', $relatedProp->id)); ?>"><?php echo e($relatedProp->title); ?></a>
                                    </h2>
                                    <span class="property-location d-block mb-3"><span
                                            class="property-icon icon-room"></span>
                                        <?php echo e($relatedProp->location); ?></span>
                                    <strong
                                        class="property-price text-primary mb-3 d-block text-success">$<?php echo e($relatedProp->price); ?></strong>
                                    <ul class="property-specs-wrap mb-3 mb-lg-0">
                                        <li>
                                            <span class="property-specs">Beds</span>
                                            <span
                                                class="property-specs-number"><?php echo e($relatedProp->beds); ?><sup>+</sup></span>

                                        </li>
                                        <li>
                                            <span class="property-specs">Baths</span>
                                            <span class="property-specs-number"><?php echo e($relatedProp->baths); ?></span>

                                        </li>
                                        <li>
                                            <span class="property-specs">SQ FT</span>
                                            <span class="property-specs-number"><?php echo e($relatedProp->sq_ft); ?></span>

                                        </li>
                                    </ul>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <h3 class="alert-danger col-md-6">There are not related properties for now</h3>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\noure\Agence-de-Location-immobili-re\projet\resources\views/props/single.blade.php ENDPATH**/ ?>