
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php if(\Session::has('success_gallery')): ?>
                        <div class="alert alert-success">
                            <p><?php echo \Session::get('success_gallery'); ?></p>
                        </div>
                    <?php endif; ?>
                    <?php if(\Session::has('error_gallery')): ?>
                        <div class="alert alert-danger">
                            <p><?php echo \Session::get('error_gallery'); ?></p>
                        </div>
                    <?php endif; ?>
                    <?php if(\Session::has('delete')): ?>
                        <div class="alert alert-danger">
                            <p><?php echo \Session::get('error_gallery'); ?></p>
                        </div>
                    <?php endif; ?>
                      <?php if(\Session::has('error_delete')): ?>
                        <div class="alert alert-danger">
                            <p><?php echo \Session::get('error_gallery'); ?></p>
                        </div>
                    <?php endif; ?>
                    <h5 class="card-title mb-4 d-inline">Properties</h5>
                    <a href="<?php echo e(route('admins.createProps')); ?>" class="btn btn-primary mb-4 text-center float-right ">Create
                        Properties</a>
                    <a href="<?php echo e(route('admins.createGallery')); ?>"
                        class="btn btn-primary mb-4 text-center float-right mr-5">Create Gallery</a>

                    <div class="table-responsive">
                        <table class="table mt-4">
                            <thead>
                                <tr>
                                    <th scope="col" width="5%">#</th>
                                    <th scope="col" width="5%">name</th>
                                    <th scope="col" width="5%">price</th>
                                    <th scope="col" width="5%">beds</th>
                                    <th scope="col" width="5%">baths</th>
                                    <th scope="col" width="5%">sq_ft</th>

                                    <th scope="col" width="5%">year_built</th>
                                    <th scope="col" width="5%"> price_sqft</th>
                                    <th scope="col" width="200px">more_info</th>
                                    <th scope="col" width="5%"> location</th>
                                    <th scope="col" width="5%">agent_name</th>
                                    <th scope="col" width="5%">type</th>
                                    <th scope="col" width="5%">city</th>
                                    <th scope="col" width="5%">delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $props; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($prop->id); ?></th>
                                        <td><?php echo e($prop->title); ?></td>
                                        <td><?php echo e($prop->price); ?></td>
                                        <td><?php echo e($prop->beds); ?></td>
                                        <td><?php echo e($prop->baths); ?></td>
                                        <td><?php echo e($prop->sq_ft); ?></td>
                                        <td><?php echo e($prop->year_built); ?></td>
                                        <td><?php echo e($prop->price_sqft); ?></td>
                                        <td><?php echo e($prop->more_info); ?></td>
                                        <td><?php echo e($prop->location); ?></td>
                                        <td><?php echo e($prop->agent_name); ?></td>
                                        <td><?php echo e($prop->type); ?></td>
                                        <td><?php echo e($prop->city); ?></td>

                                        <td>
                                            <a href="<?php echo e(route('admins.propsDelete', ['id' => $prop->id])); ?>"
                                                class="btn btn-danger text-center">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admins', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\noure\Agence-de-Location-immobili-re\projet\resources\views/admins/props.blade.php ENDPATH**/ ?>